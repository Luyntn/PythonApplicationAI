from kivy.clock import Clock
from chat_processor import process_chat_input  # Import từ file xử lý chat
from text_to_speech import speak_vietnamese  # Import module TTS


def normalize_text(text):
    text = text.strip().lower()
    text = " ".join(text.split())
    return text
def send_message(self, instance=None):
    user_input = self.chat_input.text.strip()
    if user_input:
        process_chat_input(self, user_input)  # Gọi process_chat_input từ file chat_precessor.py
        if self.process_status == 1:  # Kiểm tra nếu đã xử lý đặc biệt
            return  # Thoát khỏi hàm, không xử lý tiếp
        
        #self.append_chat("Bạn", user_input)
        append_chat(self.chat_display, self.active_ai_name, self.active_ai_name, user_input)
        self.chat_input.text = ""
        self.last_question = user_input  # Lưu lại câu hỏi cuối cùng
        history = self.load_history()
        norm_input = normalize_text(user_input)
        match = history[history["User"].apply(lambda x: normalize_text(x)) == norm_input]
        
        if not match.empty:
            # Nếu có nhiều câu trả lời, chọn ngẫu nhiên 1
            reply = match.sample(n=1).iloc[0]["Reply"]
            append_chat(self.chat_display, self.active_ai_name, self.active_ai_name, reply)

        else:
            self.show_teach_popup(user_input, history)
        
        # Đặt lại focus cho ô nhập tin nhắn sau 0.1 giây
        Clock.schedule_once(lambda dt: setattr(self.chat_input, 'focus', True), 0.1)

def append_chat(chat_display, active_ai_name, speaker, message):
   
        #Thêm tin nhắn vào khung chat.
    
        #param chat_display: Đối tượng hiển thị nội dung chat
        #param active_ai_name: Tên AI hiện tại để kiểm tra nếu AI trả lời
        #param speaker: Người nói (Bạn hoặc AI)
        #param message: Nội dung tin nhắn
        
        # Lấy nội dung hiện tại của chat_display
            current = chat_display.text if chat_display.text else ""
            new_line = "[b]{}:[/b] {}\n".format(speaker, message)

            # Tách các dòng hiện tại và thêm dòng mới
            lines = (current + new_line).strip().split("\n")
    
            # Giữ lại tối đa 4 dòng cuối cùng
            max_lines = 4
            if len(lines) > max_lines:
                lines = lines[-max_lines:]

            # Cập nhật lại nội dung hiển thị
            chat_display.text = "\n".join(lines) + "\n"  # Thêm xuống dòng cuối
    
            # Nếu là AI nói, thì đọc to câu trả lời
            if speaker == active_ai_name:
                speak_vietnamese(message)
