from gtts import gTTS
from playsound import playsound
import os

def speak_vietnamese(text):
    if not text:
        return  # Nếu không có nội dung, thoát luôn
    
    # Tạo giọng nói từ văn bản với ngôn ngữ tiếng Việt
    tts = gTTS(text=text, lang='vi')

    # Lưu file âm thanh tạm thời
    file_path = "output.mp3"
    tts.save(file_path)

    # Phát âm thanh trực tiếp trong chương trình
    playsound(file_path)

    # Xóa file sau khi phát (tránh lưu trữ không cần thiết)
    os.remove(file_path)

if __name__ == "__main__":
    speak_vietnamese("Xin chào! Đây là giọng nói tiếng Việt từ gTTS.")
