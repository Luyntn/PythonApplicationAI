import sys
import cv2
from PyQt5.QtWidgets import QApplication, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QFrame, QTextEdit, QLineEdit
from PyQt5.QtGui import QImage, QPixmap
from PyQt5.QtCore import Qt, QTimer

class ChatVideoApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("AI Chat & Video")
        self.setGeometry(100, 100, 900, 600)

        # Khung chat bên trái
        self.chat_frame = QFrame(self)
        self.chat_frame.setStyleSheet("border: 0,5px solid black;")
        self.chat_frame.setFixedSize(400, 600)
        
        self.chat_display = QTextEdit(self.chat_frame)
        self.chat_display.setReadOnly(True)
        self.chat_input = QLineEdit(self.chat_frame)
        self.send_button = QPushButton("Gửi", self.chat_frame)
        self.send_button.clicked.connect(self.send_message)

        chat_layout = QVBoxLayout(self.chat_frame)
        chat_layout.addWidget(self.chat_display)
        chat_layout.addWidget(self.chat_input)
        chat_layout.addWidget(self.send_button)

        # Khung video bên phải
        self.video_frame = QFrame(self)
        self.video_frame.setStyleSheet("border: 0,5px solid black;")
        self.video_frame.setFixedSize(440, 660)

        self.video_label = QLabel(self.video_frame)
        self.video_label.setAlignment(Qt.AlignCenter)
        self.video_label.setGeometry(0, 0, 440, 660)

        self.btn_ai1 = QPushButton("Tiểu Hồ Ly", self)
        self.btn_ai1.clicked.connect(lambda: self.run_ai("video.mp4"))
        
        self.btn_ai2 = QPushButton("Lưu Duyệt Phi", self)
        self.btn_ai2.clicked.connect(lambda: self.run_ai("video2.mp4"))
        
        video_layout = QVBoxLayout()
        video_layout.addWidget(self.video_frame)
        video_layout.addWidget(self.btn_ai1)
        video_layout.addWidget(self.btn_ai2)
        video_layout.setAlignment(Qt.AlignTop)
        
        # Layout chính (chat bên trái, video bên phải)
        main_layout = QHBoxLayout()
        main_layout.addWidget(self.chat_frame)
        main_layout.addLayout(video_layout)
        self.setLayout(main_layout)
        
        # Video
        self.cap = None
        self.running = False
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_video)
    
    # 🛠 Sửa lỗi: Đặt send_message đúng chỗ trong class
    def send_message(self):
        user_input = self.chat_input.text().strip()
        if user_input:
            self.chat_display.append("Bạn: " + user_input)
            self.chat_input.clear()

    def run_ai(self, video_path):
        self.running = False
        self.timer.stop()
        if self.cap:
            self.cap.release()
            self.cap = None
        self.cap = cv2.VideoCapture(video_path)
        if not self.cap.isOpened():
            print("Không thể mở video:", video_path)
            return
        self.running = True
        self.timer.start(60)
    
    def update_video(self):
        if not self.running or not self.cap:
            return
        ret, frame = self.cap.read()
        if not ret:
            self.timer.stop()
            return
        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = frame.shape
        bytes_per_line = ch * w
        qimg = QImage(frame.data, w, h, bytes_per_line, QImage.Format_RGB888)
        self.video_label.setPixmap(QPixmap.fromImage(qimg))

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = ChatVideoApp()
    window.show()
    sys.exit(app.exec_())
