from datetime import datetime

def process_chat_input(chat_instance, user_input):
    """ Kiểm tra tin nhắn và chọn file phù hợp """
    chat_instance.process_status = 0  # Reset trạng thái cho mỗi tin nhắn mới

    # Xử lý câu hỏi đặc biệt không cần đọc file XML
    if "time" in user_input.lower() or "hôm nay ngày gì" in user_input.lower() or "mấy giờ rồi" in user_input.lower():
        current_time = datetime.now().strftime("%H:%M:%S %d/%m/%Y")  
        chat_instance.append_chat(chat_instance.active_ai_name, "Dạ, hiện tại là: " + current_time)
        chat_instance.process_status = 1  # Hệ thống đã xử lý, dừng chương trình
        return  # Dừng hàm, không đọc file XML nữa
    
    if "chatxyz" in user_input.lower():
        chat_instance.process_status = 0  # Chưa xử lý
        history_file = "tamsu_history.xml"
        try:
            chat_instance.select_ai(history_file, "video.mp4", "Girl")
        except Exception :
            print("LỖI:", e)
